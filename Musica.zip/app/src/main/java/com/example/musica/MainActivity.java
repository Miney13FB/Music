package com.example.musica;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private MediaPlayer mp;
    private SeekBar barra;
    private Button btnPlay;
    private CheckBox bucle;
    private TextView titulo;
    private final Handler h = new Handler();
    private boolean arrastrando = false;

    private final Runnable tick = new Runnable() {
        public void run() {
            if (mp != null && mp.isPlaying()) {
                if (!arrastrando) barra.setProgress(mp.getCurrentPosition());
                h.postDelayed(this, 500);
            }
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 40, 40, 40);

        Button elegir = new Button(this);
        elegir.setText("Elegir audio");
        titulo = new TextView(this);
        titulo.setText("Ningun archivo");
        btnPlay = new Button(this);
        btnPlay.setText("Play");
        barra = new SeekBar(this);
        bucle = new CheckBox(this);
        bucle.setText("Repetir en bucle");

        l.addView(elegir); l.addView(titulo); l.addView(barra);
        l.addView(btnPlay); l.addView(bucle);
        setContentView(l);

        elegir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("audio/*");
                startActivityForResult(i, 1);
            }
        });

        btnPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mp == null) return;
                if (mp.isPlaying()) {
                    mp.pause();
                    btnPlay.setText("Play");
                } else {
                    mp.start();
                    btnPlay.setText("Pausa");
                    h.post(tick);
                }
            }
        });

        bucle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton c, boolean on) {
                if (mp != null) mp.setLooping(on);
            }
        });

        barra.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && mp != null) mp.seekTo(p);
            }
            public void onStartTrackingTouch(SeekBar s) { arrastrando = true; }
            public void onStopTrackingTouch(SeekBar s) { arrastrando = false; }
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req != 1 || res != RESULT_OK || d == null) return;
        Uri uri = d.getData();
        liberar();
        try {
            mp = new MediaPlayer();
            mp.setDataSource(this, uri);
            mp.prepare();
            mp.setLooping(bucle.isChecked());
            barra.setMax(mp.getDuration());
            barra.setProgress(0);
            titulo.setText(uri.getLastPathSegment());
            btnPlay.setText("Pausa");
            mp.start();
            h.post(tick);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) {
                    btnPlay.setText("Play");
                    barra.setProgress(0);
                }
            });
        } catch (Exception e) {
            titulo.setText("No se puede reproducir este archivo");
            liberar();
        }
    }

    private void liberar() {
        h.removeCallbacks(tick);
        if (mp != null) { mp.release(); mp = null; }
    }

    @Override protected void onDestroy() {
        liberar();
        super.onDestroy();
    }
}
